import DefaultTheme from 'vitepress/theme';
import './custom.css';

const theme: typeof DefaultTheme = {
  ...DefaultTheme,
};

export default theme;
