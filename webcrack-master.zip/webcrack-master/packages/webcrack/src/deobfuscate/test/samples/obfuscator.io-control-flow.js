function a() {
    var h = [
        '4496112hRzUwi',
        'convertESM',
        'replaceRequireCalls',
        'inlineVarInjections',
        '10034958BKGbbp',
        'modules',
        'capture',
        '4|3|0|5|2|6|1',
        'aokfw',
        'convertDefaultRequire',
        'numericLiteral',
        '596381RBbCwG',
        'identifier',
        '6506843sEFStO',
        'callExpression',
        '220wEDVBy',
        'forEach',
        '270594BMxBNt',
        '1730kqELtV',
        'split',
        '6KqUKoX',
        'HLAuI',
        'require',
        '135748VvmqOB',
        '13597944MAVUeU'
    ];
    a = function () {
        return h;
    };
    return a();
}
(function (c, d) {
    var e = c();
    while (!![]) {
        try {
            var f = -parseInt(b(0x15)) / 0x1 * (parseInt(b(0x5)) / 0x2) + parseInt(b(0xa)) / 0x3 + parseInt(b(0x8)) / 0x4 * (-parseInt(b(0x0)) / 0x5) + -parseInt(b(0xe)) / 0x6 + parseInt(b(0x17)) / 0x7 + -parseInt(b(0x9)) / 0x8 + parseInt(b(0x2)) / 0x9 * (parseInt(b(0x3)) / 0xa);
            if (f === d) {
                break;
            } else {
                e['push'](e['shift']());
            }
        } catch (g) {
            e['push'](e['shift']());
        }
    }
}(a, 0xee0d8));
function b(c, d) {
    var e = a();
    b = function (f, g) {
        f = f - 0x0;
        var h = e[f];
        return h;
    };
    return b(c, d);
}
function applyTransforms() {
    var c = {
        'HLAuI': b(0x11),
        'aokfw': b(0x7)
    };
    var d = c[b(0x6)][b(0x4)]('|');
    var e = -0x1a70 + 0x93d + 0x275 * 0x7;
    while (!![]) {
        switch (d[e++]) {
        case '0':
            (0x0, getDefaultExport_1[b(0x13)])(this);
            continue;
        case '1':
            return g;
        case '2':
            var f = m[b(0x10)](m[b(0x14)]());
            continue;
        case '3':
            this[b(0xf)][b(0x1)](esm_1[b(0xb)]);
            continue;
        case '4':
            this[b(0xf)][b(0x1)](varInjection_1[b(0xd)]);
            continue;
        case '5':
            this[b(0xc)]();
            continue;
        case '6':
            var g = m[b(0x18)](m[b(0x16)](c[b(0x12)]), [f]);
            continue;
        }
        break;
    }
}