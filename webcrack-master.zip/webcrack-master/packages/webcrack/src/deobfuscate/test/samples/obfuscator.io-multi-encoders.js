(function (e, f) {
  var l = c,
    k = d,
    j = b,
    g = e();
  while (!![]) {
    try {
      var h =
        -parseInt(j(0x16d)) / 0x1 +
        (parseInt(k(0x16e)) / 0x2) * (-parseInt(l(0x16f, 'DiKO')) / 0x3) +
        (-parseInt(j(0x170)) / 0x4) * (parseInt(k(0x165)) / 0x5) +
        (parseInt(k(0x171)) / 0x6) * (-parseInt(l(0x172, 'GeF7')) / 0x7) +
        parseInt(j(0x168)) / 0x8 +
        (parseInt(j(0x169)) / 0x9) * (-parseInt(l(0x173, 'Fymz')) / 0xa) +
        (parseInt(j(0x174)) / 0xb) * (parseInt(j(0x16c)) / 0xc);
      if (h === f) break;
      else g['push'](g['shift']());
    } catch (i) {
      g['push'](g['shift']());
    }
  }
})(a, 0x796de);
function hi() {
  var n = c,
    m = b;
  console[m(0x175)](n(0x176, '#(#D'));
}
function d(b, c) {
  var e = a();
  return (
    (d = function (f, g) {
      f = f - 0x161;
      var h = e[f];
      return h;
    }),
    d(b, c)
  );
}
function b(c, d) {
  var e = a();
  return (
    (b = function (f, g) {
      f = f - 0x161;
      var h = e[f];
      if (b['HujJww'] === undefined) {
        var i = function (m) {
          var n =
            'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';
          var o = '',
            p = '';
          for (
            var q = 0x0, r, s, t = 0x0;
            (s = m['charAt'](t++));
            ~s && ((r = q % 0x4 ? r * 0x40 + s : s), q++ % 0x4)
              ? (o += String['fromCharCode'](0xff & (r >> ((-0x2 * q) & 0x6))))
              : 0x0
          ) {
            s = n['indexOf'](s);
          }
          for (var u = 0x0, v = o['length']; u < v; u++) {
            p +=
              '%' +
              ('00' + o['charCodeAt'](u)['toString'](0x10))['slice'](-0x2);
          }
          return decodeURIComponent(p);
        };
        (b['miEOZs'] = i), (c = arguments), (b['HujJww'] = !![]);
      }
      var j = e[0x0],
        k = f + j,
        l = c[k];
      return !l ? ((h = b['miEOZs'](h)), (c[k] = h)) : (h = l), h;
    }),
    b(c, d)
  );
}
function c(b, d) {
  var e = a();
  return (
    (c = function (f, g) {
      f = f - 0x161;
      var h = e[f];
      if (c['rBcYnf'] === undefined) {
        var i = function (n) {
          var o =
            'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';
          var p = '',
            q = '';
          for (
            var r = 0x0, s, t, u = 0x0;
            (t = n['charAt'](u++));
            ~t && ((s = r % 0x4 ? s * 0x40 + t : t), r++ % 0x4)
              ? (p += String['fromCharCode'](0xff & (s >> ((-0x2 * r) & 0x6))))
              : 0x0
          ) {
            t = o['indexOf'](t);
          }
          for (var v = 0x0, w = p['length']; v < w; v++) {
            q +=
              '%' +
              ('00' + p['charCodeAt'](v)['toString'](0x10))['slice'](-0x2);
          }
          return decodeURIComponent(q);
        };
        var m = function (n, o) {
          var p = [],
            q = 0x0,
            r,
            t = '';
          n = i(n);
          var u;
          for (u = 0x0; u < 0x100; u++) {
            p[u] = u;
          }
          for (u = 0x0; u < 0x100; u++) {
            (q = (q + p[u] + o['charCodeAt'](u % o['length'])) % 0x100),
              (r = p[u]),
              (p[u] = p[q]),
              (p[q] = r);
          }
          (u = 0x0), (q = 0x0);
          for (var v = 0x0; v < n['length']; v++) {
            (u = (u + 0x1) % 0x100),
              (q = (q + p[u]) % 0x100),
              (r = p[u]),
              (p[u] = p[q]),
              (p[q] = r),
              (t += String['fromCharCode'](
                n['charCodeAt'](v) ^ p[(p[u] + p[q]) % 0x100]
              ));
          }
          return t;
        };
        (c['xBGZOf'] = m), (b = arguments), (c['rBcYnf'] = !![]);
      }
      var j = e[0x0],
        k = f + j,
        l = b[k];
      return (
        !l
          ? (c['ZFGvmW'] === undefined && (c['ZFGvmW'] = !![]),
            (h = c['xBGZOf'](h, g)),
            (b[k] = h))
          : (h = l),
        h
      );
    }),
    c(b, d)
  );
}
function a() {
  var o = [
    '2410195tJPYgk',
    'mJu3otCWzKTUteXw',
    'WQJdMgfXvLGj',
    'oty2ntG0y0Lzug1M',
    'nZqXodyXBfjRAhLR',
    '70xomFMB',
    'gCoDeSoWvJdcNxHe',
    'mtKWntGYohbeC0Tjrq',
    'nda2mJq5rfvyzeDb',
    '20qzihTP',
    'WOKbfmoOWO7dTMVcVdVcGmkw',
    'nezwq0fhEq',
    '257970fKnLLV',
    'W6xcLW9bWQ9JW5i',
    'q8kOWQldIYe5pea',
    'mtqZEvDsugnd',
    'Bg9N',
    'W4NdMSoUWOvjW5dcLGi7W7NcKa0',
    'W7RcPCkoWQ83WO8DxwnYvhW',
    'm8ovW5mYW5hdP0hcTW',
    'WQiVFslcRNTiWPhdL8o+W40',
    '4FVCAGy',
  ];
  a = function () {
    return o;
  };
  return a();
}
hi();
