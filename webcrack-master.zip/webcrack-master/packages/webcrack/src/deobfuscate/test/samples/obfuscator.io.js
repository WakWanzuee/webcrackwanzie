// v4.0.0
(function (b, e) {
  var k = d,
    f = b();
  while (!![]) {
    try {
      var g =
        -parseInt(k(0xb7)) / (-0x1 * -0x133e + -0x2b * 0x13 + -0x100c) +
        -parseInt(k(0xb8)) / (-0x16fc * 0x1 + 0x1801 * -0x1 + 0x2eff) +
        (-parseInt(k(0xb9)) / (-0x3 * -0x347 + -0x64d * 0x1 + 0x385 * -0x1)) *
          (parseInt(k(0xba)) / (0x247f + 0xa18 * 0x2 + -0x38ab)) +
        (-parseInt(k(0xbb)) / (0x1 * 0x1405 + 0x1352 + -0x2752)) *
          (parseInt(k(0xbc)) / (0x1a61 * -0x1 + 0x1c51 + 0x1 * -0x1ea)) +
        (parseInt(k(0xbd)) / (-0x1a72 + -0x238d + 0x3e06)) *
          (-parseInt(k(0xbe)) / (-0x11c3 * 0x2 + -0x9d1 + 0x17 * 0x1f9)) +
        -parseInt(k(0xbf)) / (-0x40 * 0x94 + 0x29 * 0x59 + 0x16c8) +
        (-parseInt(k(0xc0)) / (-0x1 * 0x1675 + -0x2325 + 0x39a4)) *
          (-parseInt(k(0xc1)) / (0x1c66 + -0x216f + -0xa * -0x82));
      if (g === e) break;
      else f['push'](f['shift']());
    } catch (h) {
      f['push'](f['shift']());
    }
  }
})(c, -0x1021e + -0x7eac8 + 0x17 * 0xac9c);
function c() {
  var o = [
    'while\x20(true)\x20{}',
    'apply',
    'counter',
    'debu',
    'gger',
    'call',
    '590708XPLBWj',
    '931306ycAlTF',
    '1212dZxdja',
    '88goZCZH',
    '10gkeCxS',
    '1006854ASxxtT',
    '4464481uvpzKS',
    '8Jgsyfr',
    '3685185hiRGbv',
    '10xlLBXx',
    '31674555rUfUve',
    'function\x20*\x5c(\x20*\x5c)',
    '\x5c+\x5c+\x20*(?:[a-zA-Z_$][0-9a-zA-Z_$]*)',
    'init',
    'test',
    'chain',
    'log',
    'Hello\x20World!',
    'constructor',
  ];
  c = function () {
    return o;
  };
  return c();
}
function hi() {
  var m = d,
    e = (function () {
      var f = !![];
      return function (g, h) {
        var i = f
          ? function () {
              if (h) {
                var j = h['apply'](g, arguments);
                return (h = null), j;
              }
            }
          : function () {};
        return (f = ![]), i;
      };
    })();
  (function () {
    e(this, function () {
      var l = d,
        f = new RegExp(l(0xc2)),
        g = new RegExp(l(0xc3), 'i'),
        h = a(l(0xc4));
      !f[l(0xc5)](h + l(0xc6)) || !g[l(0xc5)](h + 'input') ? h('0') : a();
    })();
  })(),
  console[m(0xc7)](m(0xc8));
  console[m(0xc7)](m(0xc811));
  console[m(0xc7)](m(-0x1));
  const p = true;
  console[m(0xc7)](m(p ? 0xc7 : 0xc8));
}
function d(a, b) {
  var e = c();
  return (
    (d = function (f, g) {
      f = f - (-0x160f * 0x1 + -0x145a + 0x2b20);
      var h = e[f];
      return h;
    }),
    d(a, b)
  );
}
hi();
function a(b) {
  function e(f) {
    var n = d;
    if (typeof f === 'string')
      return function (g) {}[n(0xc9)](n(0xca))[n(0xcb)](n(0xcc));
    else
      ('' + f / f)['length'] !== 0x23e3 + 0x12ff + -0x3 * 0x124b ||
      f % (0x41 * -0x86 + 0x2a6 + 0x1f74) === 0x19d * 0x5 + -0xf08 + 0x1 * 0x6f7
        ? function () {
            return !![];
          }
            [n(0xc9)](n(0xcd) + n(0xce))
            [n(0xcf)]('action')
        : function () {
            return ![];
          }
            [n(0xc9)](n(0xcd) + n(0xce))
            ['apply']('stateObject');
    e(++f);
  }
  try {
    if (b) return e;
    else e(-0x392 + 0x3f1 * -0x7 + 0x1f29);
  } catch (f) {}
}
