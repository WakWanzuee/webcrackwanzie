!(function (c, d) {
  var e = c();
  for (; []; ) {
      try {
          var f = parseInt(b(0xd8)) / 0x1 + parseInt(b(0xd5)) / 0x2 + parseInt(b(0xd9)) / 0x3 * (parseInt(b(0xd2)) / 0x4) + parseInt(b(0xd7)) / 0x5 + parseInt(b(0xd1)) / 0x6 * (parseInt(b(0xce)) / 0x7) + parseInt(b(0xd0)) / 0x8 * (-parseInt(b(0xd4)) / 0x9) + -parseInt(b(0xcf)) / 0xa;
          if (f === d)
              break;
          else
              e['push'](e['shift']());
      } catch (g) {
          e['push'](e['shift']());
      }
  }
}(a, 0xc0943));
function a() {
  var h = [
      'Hello\x20World!',
      '12703356uvsvpw',
      '1197882EFUbpz',
      'log',
      '1669495TVfEnH',
      '399794dRBHDZ',
      '882114ENadWR',
      '26243oazaLR',
      '20009140AGSmkm',
      '8HwbAFS',
      '2238lTRKhb',
      '20NrTGxR'
  ];
  a = function () {
      return h;
  };
  return a();
}
function b(c, d) {
  var e = a();
  return b = function (f, g) {
      f = f - 0xce;
      var h = e[f];
      return h;
  }, b(c, d);
}
function hi() {
  console[b(0xd6)](b(0xd3));
}
hi();