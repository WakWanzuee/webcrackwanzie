(window['webpackJsonp'] = window['webpackJsonp'] || []).push([
  [],
  [
    function (module, exports, __webpack_require__) {
      var json = __webpack_require__(1);
      console.log(json);
    },
    function (module, exports) {
      module.exports = { foo: 'bar' };
    },
  ],
]);
