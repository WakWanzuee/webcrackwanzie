(window.webpackJsonp = window.webpackJsonp || []).push([
  [15],
  {
    '2wwy': function (e, t, i) {
      const a = i('E8gZ');
      const b = i('w6GO');
    },
    E8gZ: function (e, t, i) {
      e.exports = 4;
    },
  },
]);
