import { Module } from '../module';

export class WebpackModule extends Module {}
